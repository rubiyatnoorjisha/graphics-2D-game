#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

#include "figures.h"
#include "enemy.h"

void timer(int value) {
    if(stop == 1)
        return;
    if(load <= 45.0)
        g_counter = -1;
    if(stop == 0) {
        g_counter += 1;
        glutPostRedisplay();
        glutTimerFunc(1000, timer, g_counter);
    }
    if(g_counter%20 == 0)
    {
        speed += 0.03;
    }
}

void timertext()
{
    char text[32] = "TIME: 0";
    //text[0]='T'; text[1]='I'; text[2]='M'; text[3]='E'; text[4]=':'; text[5]=' '; text[6]=' ';
    int strt=7;
    if(g_counter<10)
        strt--;
    int tmp=g_counter;
    while(tmp)
    {
        text[strt--]=(tmp%10)+'0';
        tmp/=10;
    }
    glColor3f(0, 0, 0);
    glRasterPos3f( -99 , 95 , 0.0);
    for(int i = 0; text[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
}

void scoretext()
{
    char text[32] = "SCORE: 0";
    //text[0]='S'; text[1]='C'; text[2]='O'; text[3]='R'; text[4]='E'; text[5]=':'; text[6]=' '; text[7]=' '; text[8]=' ';
    int strt=8;
    if(score<10)
        strt--;
    int tmp=score;
    while(tmp)
    {
        text[strt--]=(tmp%10)+'0';
        tmp/=10;
    }
    glColor3f(0, 0, 0);
    glRasterPos3f( -99 , 89 , 0.0);
    for(int i = 0; text[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, text[i]);
}

void introtext()
{
    char text1[50] = "Welcome to Minion Game";
    char text2[50] = "Press `s' to start the game";
    glColor3f(0, 0, 0);
    glRasterPos3f( -35 , -15 , 0.0);
    for(int i = 0; text1[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text1[i]);
    glRasterPos3f( -34.7 , -25 , 0.0);
    for(int i = 0; text2[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text2[i]);
}


void gameover(void)
{
    glClearColor(0.8,0.9,0.0,1.0); ///change this color -_-
    glClear(GL_COLOR_BUFFER_BIT);
    glPushMatrix();

    glPushMatrix(); ///calling logo
        glTranslatef(-32,-90,0);
        glScalef(1.3,1.3,0);
        glPushMatrix();
        //topLetters();
        //topMinions();
        glPopMatrix();
    glPopMatrix();

    char text1[50] = "Game Over";
    glColor3f(0, 0, 0);
    glRasterPos3f( -15 , -5 , 0.0);
    for(int i = 0; text1[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text1[i]);

    char text[32] = "Your Score: 0";
    int strt=13;
    if(score<10)
        strt--;
    int tmp=score;
    while(tmp)
    {
        text[strt--]=(tmp%10)+'0';
        tmp/=10;
    }
    glColor3f(0,0,0);
    glRasterPos3f(-20,-15,0.0);
    for(int i=0; text[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);

    char text3[50] = "Press 'n' to try again.";
    glColor3f(0, 0, 0);
    glRasterPos3f( -26 , -25 , 0.0);
    for(int i = 0; text3[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text3[i]);

    glPopMatrix();
    glFlush();
}

void drawbanana()
{
    if((bx >= tx-4 && bx <= tx+4) && (by >= ty-6 && by <= ty+4))
    {
        score++;
        bx = rand() % (95 - (-95) + 1) + (-95);
        by = rand() % (23 - (-70) + 1) + (-70);
        ///BANANA scaling
        if(by>=16 && by<=25) { bsx= 0.3; bsy = 0.3; }
        else if(by>=10 && by<=15) { bsx= 0.3; bsy = 0.3; }
        else if(by>=0 && by<=9) { bsx= 0.4; bsy = 0.4; }
        else if(by>=-10 && by<=-1) { bsx= 0.4; bsy = 0.4; }
        else if(by>=-20 && by<=-9) { bsx= 0.5; bsy = 0.5; }
        else if(by>=-30 && by<=-19) { bsx= 0.6; bsy = 0.6; }
        else if(by>=-40 && by<=-29) { bsx= 0.7; bsy = 0.7; }
        else if(by>=-50 && by<=-39) { bsx= 0.8; bsy = 0.8; }
        else if(by>=-60 && by<=-49) { bsx= 0.9; bsy = 0.9; }
        else if(by>=-70 && by<=-59) { bsx= 1.0; bsy = 1.0; }
        PlaySound("Banana_Eating.wav", NULL, SND_FILENAME| SND_ASYNC);
    }
    glPushMatrix();
        glTranslatef(bx,by,0.0);
        glRotatef(-35,0,0,1);
        glScalef(bsx,bsy,0);
        glPushMatrix();
            glColor3f(0.0,0.0,0.0);
            circle(4.5,5);
            circle(2.7,4.7);
            glColor3f(1.0,1.0,0.0);
            circle(2,4);
            glTranslatef(-2,0,0);
            glColor3f(0.0,0.0,0.0);
            circle(2,4);
        glPopMatrix();
        //glutPostRedisplay();
    glPopMatrix();
}

void displayBackground(void){
    glClear(GL_COLOR_BUFFER_BIT);
    glPushMatrix();
        //PlayField:
        glPushMatrix();
        glColor3f(0.69, 0.99, 0.39);
        glBegin(GL_POLYGON);
        glVertex2f(100, 100);
        glVertex2f(100, -100);
        glVertex2f(-100, -100);
        glVertex2f(-100, 100);
        glEnd();

        ///TREE (small)
        tree3();

        ///BACK FIELD
        glPushMatrix();
            glTranslatef(0,-30,0);
            glRotatef(-5,0,0,1);
            glColor3f(0.5,0.99,0.0);
            circle(200,50);
        glPopMatrix();

        ///TREE (middle)
        tree2();

        ///MIDDLE FIELD
        glPushMatrix();
            glTranslatef(-50,-56,0);
            glRotatef(10,0,0,1);
            glColor3f(0.39,0.79,0.0);
            circle(200,53);
        glPopMatrix();

        ///TREE (large)
        tree1();

        ///FRONT FIELD
        glPushMatrix();
            glTranslatef(0,-90,0);
            glRotatef(-12,0,0,1);
            glColor3f(0.29,0.59,0.0);
            circle(200,50);
        glPopMatrix();

        glPopMatrix();
        //TopHEADER:
        glPushMatrix();
        glColor3f(0.8, 0.8, 0.9);
        glBegin(GL_POLYGON);
        glVertex2f(100, 100);
        glVertex2f(100, 88);
        glVertex2f(-100, 88);
        glVertex2f(-100, 100);
        glEnd();
        glPopMatrix();

        ///calling ghost
        if(g_counter>=5)
            Enemy1();
        if(g_counter>=20)
            Enemy2();
        if(g_counter>=40)
            Enemy3();
        if(g_counter>=60)
            Enemy6();

        //BackGround:
        glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.0, 0.8);
        glVertex2f(100, 25);
        glColor3f(0.0, 0.0, 1.0);
        glVertex2f(100, 83);
        glColor3f(0.5, 0.0, 0.8);
        glVertex2f(-100, 83);
        glColor3f(1.0, 1.0, 0.3);
        glVertex2f(-100, 25);
        glEnd();
        //Buildings:
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.6, 0.8);
        glVertex2f(95, 25);
        glVertex2f(95, 40);
        glVertex2f(85, 40);
        glVertex2f(85, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.4, 0.5);
        glVertex2f(-80, 25);
        glVertex2f(-80, 40);
        glVertex2f(-70, 40);
        glVertex2f(-70, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.6, 0.8);
        glVertex2f(60, 25);
        glVertex2f(60, 40);
        glVertex2f(50, 40);
        glVertex2f(50, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.6, 0.5);
        glVertex2f(55, 25);
        glVertex2f(55, 35);
        glVertex2f(45, 35);
        glVertex2f(45, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.4, 0.8);
        glVertex2f(-45, 25);
        glVertex2f(-45, 40);
        glVertex2f(-35, 40);
        glVertex2f(-35, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.6, 0.6);
        glVertex2f(-30, 25);
        glVertex2f(-30, 35);
        glVertex2f(-20, 35);
        glVertex2f(-20, 25);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3f(0.5, 0.6, 0.5);
        glVertex2f(-60, 25);
        glVertex2f(-60, 40);
        glVertex2f(-50, 40);
        glVertex2f(-50, 25);
        glEnd();
        glPopMatrix();
        //treeBesideBuildings
        ///cloud
        cloud1();
        cloud2();
        //Footer:
        glPushMatrix();
        glColor3f(0.8, 0.8, 0.9);
        glBegin(GL_POLYGON);
        glVertex2f(100, -90);
        glVertex2f(100, -100);
        glVertex2f(-100, -100);
        glVertex2f(-100, -90);
        glEnd();
        glPopMatrix();
        //TopGameLogo:
        //topLetters();
        //topMinions();
        //banana
        drawbanana();

        if(startgame==0)
            introtext();
        timertext();
        scoretext();
        if(endgame == 1)
            glutDisplayFunc(gameover);

    glPopMatrix();
}
void displayFront(void) {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();
    displayBackground();

    ///MOVE
    glPushMatrix();
    glTranslatef(tx,ty,0);
    glScalef(sx,sy,0);
        glPushMatrix();
        ///headup:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0.0,0.0,0.0);
        circle(5,5);
        glPopMatrix();

        ///headmiddle:
        glColor3f(1.0, 1.0, 0.0);
        glPushMatrix();
        glTranslatef(0.0,-5,0.0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///headEyeBlack:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,0,0);
        circle(3,3);
        glPopMatrix();
        ///headEyeWhite:
        glPushMatrix();
        glColor3f(1.0, 1.0, 1.0);
        glTranslatef(0,0,0);
        circle(2.5,2.5);
        glPopMatrix();
        ///headEyeBlackCenter:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,0,0);
        circle(1,1);
        glPopMatrix();
        ///headEyeBandLeft:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(-4,0.0,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.5, 0.5);
        glVertex2f(1.5, -0.5);
        glVertex2f(-1, -0.5);
        glVertex2f(-1, 0.5);
        glEnd();
        glPopMatrix();
        ///headLip:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,-4,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 0.1);
        glVertex2f(1, -0.2);
        glVertex2f(-1, -0.2);
        glVertex2f(-1, 0.1);
        glEnd();
        glPopMatrix();
        ///headEyeBandRight:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(4,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.5, 0.5);
        glVertex2f(1.5, -0.5);
        glVertex2f(-1, -0.5);
        glVertex2f(-1, 0.5);
        glEnd();
        glPopMatrix();
        ///body:
        glPushMatrix();
        glColor3f(0.0, 0.0, 1.0);
        glTranslatef(0,-10,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///bodyLeft:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(-4,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyRight:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(4,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegLeft:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(-1.1,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegRight:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(1.1,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegLeftShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(-1.1,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 0.5);
        glVertex2f(0.5, -0.5);
        glVertex2f(-1.5, -0.5);
        glVertex2f(-1.5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyLegRightShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(1.1,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.5, 0.5);
        glVertex2f(1.5, -0.5);
        glVertex2f(-0.5, -0.5);
        glVertex2f(-0.5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyHandLeft:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(-5,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
        ///bodyHandRight:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(5,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
    glPopMatrix();
    glPopMatrix();
    glPopMatrix();
    glFlush();
}
void displayBack(void) {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();
    displayBackground();

    ///MOVE
    glPushMatrix();
    glTranslatef(tx,ty,0);
    glScalef(sx,sy,0);
        ///headup:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0,0,0);
        circle(5,5);
        glPopMatrix();

        ///headmiddle:
        glColor3f(1.0, 1.0, 0.0);
        glPushMatrix();
        glTranslatef(0,-5,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///headEyeBandBack:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 0.5);
        glVertex2f(5, -0.5);
        glVertex2f(-5, -0.5);
        glVertex2f(-5, 0.5);
        glEnd();
        glPopMatrix();
        ///body:
        glPushMatrix();
        glColor3f(0.0, 0.0, 1.0);
        glTranslatef(0,-10,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///bodyLeft:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(-4,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyRight:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(4,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegLeft:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(-1.1,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegRight:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(1.1,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegLeftShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(-1.1,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 0.5);
        glVertex2f(0.5, -0.5);
        glVertex2f(-1.5, -0.5);
        glVertex2f(-1.5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyLegRightShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(1.1,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.5, 0.5);
        glVertex2f(1.5, -0.5);
        glVertex2f(-0.5, -0.5);
        glVertex2f(-0.5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyHandLeft:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(-5,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
        ///bodyHandRight:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(5,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
    glPopMatrix();

    glPopMatrix();
    glFlush();
}
void displayRight(void) {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();
    displayBackground();

    ///MOVE
    glPushMatrix();
    glTranslatef(tx,ty,0);
    glScalef(sx,sy,0);
        ///headup:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0,0,0);
        circle(5,5);
        glPopMatrix();

        ///headmiddle:
        glColor3f(1.0, 1.0, 0.0);
        glPushMatrix();
        glTranslatef(0,-5,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///headEyeBandBack:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 0.5);
        glVertex2f(5, -0.5);
        glVertex2f(-5, -0.5);
        glVertex2f(-5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyEye:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(5,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 2);
        glVertex2f(1, -2);
        glVertex2f(-1, -2);
        glVertex2f(-1, 2);
        glEnd();
        glPopMatrix();
        ///body:
        glPushMatrix();
        glColor3f(0.0, 0.0, 1.0);
        glTranslatef(0,-10,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///bodyMiddle:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(0,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.8, 1);
        glVertex2f(1.8, -1);
        glVertex2f(-1.8, -1);
        glVertex2f(-1.8, 1);
        glEnd();
        glPopMatrix();
        ///bodyLeg:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(0,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegRightShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.7, 0.5);
        glVertex2f(1.7, -0.5);
        glVertex2f(-0.7, -0.5);
        glVertex2f(-0.7, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyHand:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
    glPopMatrix();

    glPopMatrix();
    glFlush();
}
void displayLeft(void) {
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();
    displayBackground();

    ///MOVE
    glPushMatrix();
    glTranslatef(tx,ty,0);
    glScalef(sx,sy,0);
        ///headup:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0,0,0);
        circle(5,5);
        glPopMatrix();

        ///headmiddle:
        glColor3f(1.0, 1.0, 0.0);
        glPushMatrix();
        glTranslatef(0,-5,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///headEyeBandBack:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 0.5);
        glVertex2f(5, -0.5);
        glVertex2f(-5, -0.5);
        glVertex2f(-5, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyEye:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(-5,0,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 2);
        glVertex2f(1, -2);
        glVertex2f(-1, -2);
        glVertex2f(-1, 2);
        glEnd();
        glPopMatrix();
        ///body:
        glPushMatrix();
        glColor3f(0.0, 0.0, 1.0);
        glTranslatef(0,-10,0);
        glBegin(GL_POLYGON);
        glVertex2f(5, 5);
        glVertex2f(5, -1);
        glVertex2f(-5, -1);
        glVertex2f(-5, 5);
        glEnd();
        glPopMatrix();
        ///bodyMiddle:
        glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(0,-6.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(1.8, 1);
        glVertex2f(1.8, -1);
        glVertex2f(-1.8, -1);
        glVertex2f(-1.8, 1);
        glEnd();
        glPopMatrix();
        ///bodyLeg:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.7);
        glTranslatef(0,-12,0);
        glBegin(GL_POLYGON);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
        glVertex2f(-1, 1);
        glEnd();
        glPopMatrix();
        ///bodyLegLeftShoe:
        glPushMatrix();
        glColor3f(0.0, 0.0, 0.0);
        glTranslatef(0,-13.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.7, 0.5);
        glVertex2f(0.7, -0.5);
        glVertex2f(-1.7, -0.5);
        glVertex2f(-1.7, 0.5);
        glEnd();
        glPopMatrix();
        ///bodyHand:
        glPushMatrix();
        glColor3f(1.0, 1.0, 0.0);
        glTranslatef(0,-7.5,0);
        glBegin(GL_POLYGON);
        glVertex2f(0.5, 2);
        glVertex2f(0.5, -2);
        glVertex2f(-0.5, -2);
        glVertex2f(-0.5, 2);
        glEnd();
        glPopMatrix();
    glPopMatrix();

    glPopMatrix();
    glFlush();
}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    if(load <= 45.0)
        load += 0.092 ;
    if(load > 45.0)
        glutDisplayFunc(displayFront); ///calling the GAME PAGE
    glutPostRedisplay();
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();
    glTranslatef(0,-3,0);
    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_POLYGON);
        glVertex2f(-45,-68);
        glVertex2f(load,-68);
        glVertex2f(load,-74);
        glVertex2f(-45,-74);
    glEnd();
    glPopMatrix();
	glFlush();
}

#endif // FUNCTIONS_H_INCLUDED
